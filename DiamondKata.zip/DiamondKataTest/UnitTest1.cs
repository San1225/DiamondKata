using Microsoft.VisualStudio.TestTools.UnitTesting;
using DiamondKata;

namespace DiamondKataTest
{
    [TestClass]
    public class UnitTest1
    {
        private const string splChar = "Special Character entered. Please enter only Characters";
        private const string invalidNumber = "Number entered. Please enter only Characters";
        private const string multipleChars = "Multiple Characters entered. Please enter only one character";

        [TestMethod]
        public void PrintDiamond_ShouldReturn_NumericError_When_NumberIsEntered()
        {
            string chr = "123";
            Assert.AreEqual(invalidNumber, DiamondKata.Program.ValidateChar(chr));
        }

        [TestMethod]
        public void PrintDiamond_ShouldReturn_NumericError_When_MultipleCharsAreEntered()
        {
            string chr = "abc";
            Assert.AreEqual(multipleChars, DiamondKata.Program.ValidateChar(chr));
        }

        [TestMethod]
        public void PrintDiamond_ShouldReturn_NumericError_When_SpecialCharIsEntered()
        {
            string chr = "$";
            Assert.AreEqual(splChar, DiamondKata.Program.ValidateChar(chr));
        }

        [TestMethod]
        public void PrintDiamond_ShouldReturn_ADiamond_When_AIsEntered()
        {
            string testDiamond = "A";
            Assert.AreEqual(testDiamond, DiamondKata.Program.CreateDiamond('A'));
        }

        [TestMethod]
        public void PrintDiamond_ShouldReturn_DDiamond_When_DIsEntered()
        {
            string testDiamond = "   A\n" +
                                   "  B B\n" +
                                   " C   C\n" +
                                   "D     D\n" +
                                   " C   C\n" +
                                   "  B B\n" +
                                   "   A";
            Assert.AreEqual(testDiamond, DiamondKata.Program.CreateDiamond('D'));
        }

    }
}
