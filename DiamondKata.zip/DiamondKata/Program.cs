﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace DiamondKata
{
    public class Program
    {

        private const char firstLetter = 'A';
        private const char padChr = ' ';
        private const string sep = "\n";
        private const string splChar = "Special Character entered. Please enter only Characters";
        private const string invalidNumber = "Number entered. Please enter only Characters";
        private const string multipleChars = "Multiple Characters entered. Please enter only one character";
        static void Main(string[] args)
        {
            EnterChar();
            Console.ReadLine();
        }

        private static void EnterChar()
        {
            Console.WriteLine("Enter the Character");
            string chr = Console.ReadLine();
            string retVal = ValidateChar(chr);

            if(retVal == invalidNumber || retVal == multipleChars || retVal == splChar)
            {                
                EnterChar();
            }

        }

        public static string ValidateChar(string chr)
        {
            
            if(char.IsDigit(chr[0]))
            {
                Console.WriteLine(invalidNumber);
                return invalidNumber;
            }
            else if (!char.IsLetter(chr[0]))
            {
                Console.WriteLine(splChar);
                return splChar;                
            }
            else if (chr.Length > 1)
            {
                Console.WriteLine(multipleChars);
                return multipleChars;                
            }
            else
            {
                Console.WriteLine(CreateDiam(chr));
                return CreateDiam(chr);   
            }
        }

        private static string CreateDiam(string chr)
        {
            string final = CreateDiamond(char.ToUpper(chr[0]));            
            return final;            
        }


        public static string CreateDiamond(char diamondChr)
        {
            if (diamondChr == firstLetter) return "A";

            return FinalOutput(HalfOutput(diamondChr));
        }

        private static List<string> HalfOutput(char diamondChr)
        {
            var lines = new List<string>();
            int left = diamondChr - firstLetter;
            int len = left + 1;
            int middle = 1;

            foreach (var character in Enumerable.Range('A', diamondChr + 1 - 'A'))
            {
                lines.Add(DiamondLn(left, character, middle));
                len = ++len;
                left = --left;
                
                middle = len - left - 2;
            }
            return lines;
        }

        private static string FinalOutput(List<string> diamondLst)
        {
            var halfDiamond = string.Join(sep, diamondLst);
            diamondLst.Reverse();
            return halfDiamond + sep + string.Join(sep, diamondLst.Skip(1));
        }

        private static string DiamondLn(int left, int diamondChar, int middle)
        {
            var diamondChr = Convert.ToChar(diamondChar);
            var line = string.Empty.PadLeft(left, padChr) + diamondChr;

            if (diamondChr != firstLetter)
            {
                line += string.Empty.PadLeft(middle, padChr) + diamondChr;
            }
            return line;
        }

    }
}
